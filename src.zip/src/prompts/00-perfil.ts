// ===============================
// File: src/prompts/00-perfil.ts
// ===============================
const perfilClientePrompt = ``;

export default perfilClientePrompt;