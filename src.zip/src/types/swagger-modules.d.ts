// custom type declarations for Swagger
declare module 'swagger-jsdoc';
declare module 'swagger-ui-express';